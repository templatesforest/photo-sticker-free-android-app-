package com.passiontocode.photo_sticker;

public class Mylist {
 
	int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
