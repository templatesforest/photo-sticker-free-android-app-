package com.passiontocode.photo_sticker;

import java.io.FileNotFoundException;

import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.passiontocode.photo_sticker.R;
import com.passiotocode.utils.BitmapScalingUtil;


public class DisplayImage extends Activity {

	ImageButton share, close;
	ImageView img;
	String path;
	 SharedPreferences sp1;
	    Dialog rate1;
	
	private InterstitialAd interstitial;

	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		interstitial = new InterstitialAd(getApplicationContext());
		// Insert the Ad Unit ID
		interstitial.setAdUnitId("ca-app-pub-2691806550199991/7689983468");

		setContentView(R.layout.display_image);
		//this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		Toast.makeText(DisplayImage.this, "Image Saved to SD Card", Toast.LENGTH_SHORT).show();
		 rate1 = new Dialog(getApplicationContext());
	        sp1 = getSharedPreferences("rating", 0);
		
		
		AdView adView = (AdView) findViewById(R.id.adView);
	
		AdRequest adRequest1 = new AdRequest.Builder()
	    .build();
		adView.loadAd(adRequest1);
		
		 

		// Load ads into Interstitial Ads
		interstitial.loadAd(adRequest1);

		// Prepare an Interstitial Ad Listener
		interstitial.setAdListener(new AdListener() {
			public void onAdLoaded() {
				// Call displayInterstitial() function
				displayInterstitial();
			}

		});

		// ========end ad mob========

		img = (ImageView) findViewById(R.id.img);
		close = (ImageButton) findViewById(R.id.close);
		close.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(DisplayImage.this, MainActivity.class);
				startActivity(i);
			}
		});
		Intent i = getIntent();

		if (i.hasExtra("path")) {

			Bitmap bitmap = null;
			try {

				path = i.getStringExtra("path");
				bitmap = BitmapScalingUtil.bitmapFromUri(this, Uri.parse("file://" + path));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			img.setImageBitmap(bitmap);

		}

		share = (ImageButton) findViewById(R.id.button1);
		share.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = null;
				intent = new Intent(Intent.ACTION_SEND);
				intent.setType("image/*");
				Uri bmpUri = Uri.parse(path);
				intent.putExtra(Intent.EXTRA_STREAM, bmpUri);
				intent.putExtra(Intent.EXTRA_TEXT, bmpUri);

				startActivity(Intent.createChooser(intent, "compatible apps:"));

			}
		});

	}

	public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			final int halfHeight = height / 2;
			final int halfWidth = width / 2;

			// Calculate the largest inSampleSize value that is a power of 2 and
			// keeps both
			// height and width larger than the requested height and width.
			while ((halfHeight / inSampleSize) > reqHeight && (halfWidth / inSampleSize) > reqWidth) {
				inSampleSize *= 2;
			}
		}

		return inSampleSize;
	}

	public Bitmap decodeSampledBitmapFromUri(Uri uri, int reqWidth, int reqHeight) {

		Bitmap bm;

		try {
			// First decode with inJustDecodeBounds=true to check dimensions
			final BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeStream(getContentResolver().openInputStream(uri), null, options);

			// Calculate inSampleSize
			options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

			// Decode bitmap with inSampleSize set
			options.inJustDecodeBounds = false;
			bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(uri), null, options);
			return bm;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
		}

		return null;
	}
	
//	@Override
//  public boolean onKeyDown(int keyCode, KeyEvent event) {
//
//      if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
//         // interstitialAds .show();
//          if (sp1.getString("rate", "").contentEquals(""))
//              show_alert("Rate App","Rate this app as 5 stars !!");
//          else
//              onBackPressed();
//          return true;
//      }
//      return super.onKeyDown(keyCode, event);
//  }

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
    show_alert("Exit","Sure You Want To Exit ?");
      
	}

	 public void show_alert(String title,String msg) {

	        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
	                DisplayImage.this);

	        // set title
	        alertDialogBuilder.setTitle(title);

	        // set dialog message
	        alertDialogBuilder
	                .setMessage(msg)
	                .setCancelable(false)
	                .setIcon(R.drawable.icon_cancel).setNegativeButton("YES", new DialogInterface.OnClickListener() {

	            @Override
	            public void onClick(DialogInterface dialog, int which) {
	                // TODO Auto-generated method stub
//	                rate1.dismiss();
//	                finish();
	            	
	            	 Intent i=new Intent(getApplicationContext(),MainActivity.class);
                     i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                     i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                     startActivity(i);
                     finish();

	            }
	        })
	                .setPositiveButton("NO",new DialogInterface.OnClickListener() {
	                    public void onClick(DialogInterface dialog,int id) {
	                      
	                    	 rate1.dismiss();
	                    }
	                });



	        // create alert dialog
	        AlertDialog alertDialog = alertDialogBuilder.create();
	        // show it
	        alertDialog.show();

	        Button b = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
	        Button b1 = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
	        if(b != null)
	            b.setTextColor(Color.RED);
	        if(b1 != null)
	            b1.setTextColor(Color.RED);
	    }
	public void displayInterstitial() {
		// If Ads are loaded, show Interstitial else show nothing.
		if (interstitial.isLoaded()) {
			interstitial.show();
		}
	}
}
