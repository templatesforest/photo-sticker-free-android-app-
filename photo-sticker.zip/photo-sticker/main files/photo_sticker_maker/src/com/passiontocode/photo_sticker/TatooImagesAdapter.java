package com.passiontocode.photo_sticker;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import com.passiontocode.photo_sticker.R;

public class TatooImagesAdapter extends BaseAdapter{

	ImageView imgIcon ;
	ArrayList<Mylist> myList = new ArrayList<Mylist>();
	


	LayoutInflater inflater; 
	Context context;
	Activity activity;
	String fragmentName;
	
	  int itemBackground;

	public TatooImagesAdapter(Activity activity2,ArrayList<Mylist> myList2) {

		this.myList = myList2; 
		this.activity=activity2;
		//inflater = LayoutInflater.from(activity);
//		TypedArray attr = context.obtainStyledAttributes(R.styleable.FiltersGallery);
//		itemBackground = attr.getResourceId(R.styleable.FiltersGallery_android_galleryItemBackground, 0);
//		attr.recycle();
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return myList.size();
	}

	public Mylist getItem(int position) {

		return myList.get(position);
	}


	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) 
	{
		
		ImageView imageView = new ImageView(activity);
		 imageView.setImageResource(myList.get(position).getId());
		 imageView.setLayoutParams(new Gallery.LayoutParams(150, 120));
		 imageView.setHorizontalFadingEdgeEnabled(false);
		 imageView.setPadding(15, 0, 15, 0);
		 imageView.setScaleType(ImageView.ScaleType.FIT_XY);
		 imageView.setBackgroundResource(itemBackground);
		 return imageView;
//		final MyViewHolder mViewHolder;   
//		if(convertView == null) 
//		{ 	
//
//			mViewHolder = new MyViewHolder(); 
//			convertView = inflater.inflate(R.layout.tatoo_image_list, null);
//			
//			
//			mViewHolder.mImageView=(ImageView)convertView.findViewById(R.id.tatoo_image);
//			convertView.setTag(mViewHolder);
//		} 
//		else
//		{
//			mViewHolder = (MyViewHolder) convertView.getTag();
//		}
//		mViewHolder.mImageView.setImageResource(myList.get(position).getId());
//		
//		
//		return convertView;
	}
	private class MyViewHolder 
	{ 
		TextView mTextViewName;
		TextView mTextViewKms;
		TextView mTextViewPrice;
		TextView mTextViewAds;
		ImageView mImageView;
	} 
}
