package com.passiontocode.photo_sticker;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.IntentSender.OnFinished;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.ColorDrawable;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Gallery;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;

import com.chiralcode.colorpicker.ColorPickerDialog;
import com.chiralcode.colorpicker.ColorPickerDialog.OnColorSelectedListener;
//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.AdView;
//import com.google.android.gms.ads.InterstitialAd;
import com.myandroid.views.MultiTouchListener;
import com.myandroid.views.myView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.passiontocode.editoractivity.EditorSaveConstants;
import com.passiontocode.graphics.CommandsPreset;
import com.passiontocode.graphics.ImageProcessor;
import com.passiontocode.graphics.ImageProcessorListener;
import com.passiontocode.graphics.commands.ImageProcessingCommand;
import com.passiontocode.photo_sticker.R;
import com.passiotocode.utils.BitmapScalingUtil;
//import com.waycreon.picmaker.SelectedImageActivity;
//import com.waycreon.picmaker.DisplayImage;
//import com.waycreon.picmaker.SelectedImageActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
//import com.devsmart.android.ui.HorizontialListView;

@SuppressWarnings("deprecation")
@SuppressLint("NewApi")
public class MainActivity extends Activity implements Callback, OnClickListener, ImageProcessorListener {
	private InterstitialAd interstitial;

	Camera camera;
	SurfaceView surfaceView;
	SurfaceHolder surfaceHolder;
	ImageView mImageViewCamera;
	ImageView mImageViewGallery;
	ImageView mImageViewCapture;
	ImageView mImageViewFrontCamera;
	ImageView mImageViewSave;
	ImageView mImageViewGalleryImage;
	ImageView mImageViewOpenGallery;
	ImageView mImageViewOpenCamera;
	//ImageView mImageViewShare;
	ImageView delete_btn;
	ImageView effect,emoji;
	String mImagename;
	ArrayList<myView> imageViewArray = new ArrayList<myView>();

	PictureCallback jpegCallback;
	public Bitmap bitmaptemp = null;
	Bitmap mBitmap;
	LinearLayout mLinearLayoutButtons;
	RelativeLayout mRelativeLayoutCapture;
	RelativeLayout mRelativeLayoutMain;
	private ImageProcessor imageProcessor;
	FrameLayout rr_1;
	Boolean isClicked = false;
	Boolean isGallaryopen = false;
	File file;
	int camId;
	Matrix matrix = new Matrix();
	Matrix savedMatrix = new Matrix();
	AutoResizeTextView mTv_text;
	Boolean isImgAdded = false;
	// We can be in one of these 3 states
	static final int NONE = 0;
	static final int DRAG = 1;
	static final int ZOOM = 2;
	private static final int PICTURE_TAKEN_FROM_GALLERY = 1;
	int mode = NONE;
	ProgressDialog progress;
	private ProgressBar progressBar;
	// Remember some things for zooming
	PointF start = new PointF();
	PointF mid = new PointF();
	float oldDist = 1f;
	String savedItemClicked;
	Integer[] frameId = new Integer[] { R.drawable.rage_1,R.drawable.rage_2,R.drawable.rage_3,R.drawable.rage_4,R.drawable.rage_5,
			R.drawable.rage_6,R.drawable.rage_7,R.drawable.rage_8,R.drawable.rage_9,R.drawable.rage_10,R.drawable.rage_11,
			R.drawable.rage_12,R.drawable.rage_13,R.drawable.rage_14,R.drawable.rage_15,R.drawable.rage_16,R.drawable.rage_17,
			R.drawable.rage_18,R.drawable.rage_19,R.drawable.rage_20,R.drawable.rage_21,R.drawable.rage_22,R.drawable.rage_23,
			R.drawable.rage_24,R.drawable.rage_25,R.drawable.rage_26,R.drawable.rage_27,R.drawable.rage_28,R.drawable.rage_29,
			R.drawable.rage_30,R.drawable.rage_31,R.drawable.rage_32,R.drawable.rage_33,R.drawable.rage_34,R.drawable.rage_35,
			R.drawable.rage_36,R.drawable.rage_37,R.drawable.rage_38,R.drawable.rage_39,R.drawable.rage_40,R.drawable.rage_41,
			R.drawable.rage_42,R.drawable.rage_43,R.drawable.rage_44,R.drawable.rage_45,R.drawable.rage_46,R.drawable.rage_47,
			R.drawable.rage_48,R.drawable.rage_49,R.drawable.rage_50,R.drawable.rage_51,R.drawable.rage_52,R.drawable.rage_53,
			R.drawable.rage_54,R.drawable.rage_55,R.drawable.rage_56,R.drawable.rage_57,R.drawable.rage_58,R.drawable.rage_59,
			R.drawable.rage_60,R.drawable.rage_61,R.drawable.rage_62,R.drawable.rage_63,R.drawable.rage_64,R.drawable.rage_65,
			};
	ArrayList<Mylist> mlist = new ArrayList<Mylist>();
	// ListView mListView;
	Gallery galleryview;
	private Gallery gallery;
	public static final int RESTORE_PREVIEW_BITMAP = 1;
	Boolean moving;
	float currX, currY = 0.0f;
	int id = 0;
	ArrayList<ImageView> mArrayList = new ArrayList<ImageView>();
	ImageView[] mImageView;
	int i;
	ScaleGestureDetector scaleGestureDetector;
	LayoutParams params;
	private float scale = 1f;
	private ScaleGestureDetector SGD;
	 SharedPreferences sp1;
	    Dialog rate1;
	
	Bitmap mBitmapCamera;
	Bitmap mBitmapDrawing;
	Bitmap mBitmapMain = null;
	Bitmap takenPictureData = null;
	boolean imageSaved = false;
	// InterstitialAd interstitialAds;
	// AdRequest adRequest;
	boolean isDelete = false;
	EditText edText;
	Spinner mSpinner_text_style;
	ImageButton mIbtn_color_text;
	Global global;
	String style[] = { "1.ttf", "2.ttf", "3.ttf", "4.ttf", "5.ttf", "6.ttf", "7.ttf", "8.ttf" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		 rate1 = new Dialog(getApplicationContext());
	     sp1 = getSharedPreferences("rating", 0);
				
		global = ((Global) getApplication());
		mTv_text = new AutoResizeTextView(getApplicationContext());

		for (int i = 0; i < frameId.length; i++) {
			Mylist m = new Mylist();				
			    m.setId(frameId[i]);
				mlist.add(m);
							
		}

		imageSaved = false;
		galleryview = (Gallery) findViewById(R.id.gallery1);
		galleryview.setAdapter(new TatooImagesAdapter(this, mlist));

		// mListView = (ListView) findViewById(R.id.list_tatoo);
		getList();
		SGD = new ScaleGestureDetector(this, new ScaleListener());
		camId = Camera.CameraInfo.CAMERA_FACING_BACK;
		setCamFocusMode();

		rr_1 = (FrameLayout) findViewById(R.id.rr_1);
	
		params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

		mImageViewCamera = (ImageView) findViewById(R.id.imageview_camera);
		mImageViewGallery = (ImageView) findViewById(R.id.imageview_gallery);
		mImageViewFrontCamera = (ImageView) findViewById(R.id.imageview_front_camera);
		mImageViewCapture = (ImageView) findViewById(R.id.imageview_capture);
		// mImageViewTatoo = (ImageView) findViewById(R.id.imageview_tatoo);
		mImageViewSave = (ImageView) findViewById(R.id.imageview_save);
		mImageViewGalleryImage = (ImageView) findViewById(R.id.imageview_from_gallery);
		//mImageViewShare = (ImageView) findViewById(R.id.imageview_share);
		mImageViewOpenCamera = (ImageView) findViewById(R.id.image_camera);
		mImageViewOpenGallery = (ImageView) findViewById(R.id.image_gallery);
		effect = (ImageView) findViewById(R.id.iv_effect);
		emoji=(ImageView)findViewById(R.id.emoji_effect);
		emoji.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				gallery.setVisibility(View.INVISIBLE);
				galleryview.setVisibility(View.VISIBLE);
			}
		});

		gallery = (Gallery) findViewById(R.id.filter_gallery);
		gallery.setAdapter(new ImageAdapter(this));
		gallery.setOnItemClickListener(listener);
		gallery.setVisibility(View.GONE);

		// gallery.setVisibility(View.VISIBLE);
		delete_btn = (ImageView) findViewById(R.id.delete_btn);
		mRelativeLayoutCapture = (RelativeLayout) findViewById(R.id.layout_capture_image);
		mLinearLayoutButtons = (LinearLayout) findViewById(R.id.layout_buttons);
		mRelativeLayoutMain = (RelativeLayout) findViewById(R.id.capture_id_rl);

		rr_1.addView(mTv_text);
		mImageViewCamera.setOnClickListener(this);
		mImageViewGallery.setOnClickListener(this);
		mImageViewCapture.setOnClickListener(this);
		mImageViewFrontCamera.setOnClickListener(this);
		mImageViewSave.setOnClickListener(this);
		mImageViewOpenCamera.setOnClickListener(this);
		//mImageViewShare.setOnClickListener(this);
		mImageViewOpenGallery.setOnClickListener(this);

		delete_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				ckhDelete();
				delete_btn.setVisibility(v.VISIBLE);
				// interstitialAds.show();
				isDelete = !isDelete;

			}
		});

		galleryview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// interstitialAds.show();
				
				myView myViewTemp = new myView(getApplicationContext());
				myViewTemp.setImageResource(mlist.get(arg2).getId());

				myViewTemp.setOnTouchListener(new MultiTouchListener());
				addView(myViewTemp);
				isDelete = false;
				ckhDelete();
				

			}
		});

		effect.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				isGallaryopen = true;
				if (gallery.getVisibility() == View.VISIBLE) {

					gallery.setVisibility(View.INVISIBLE);
					Log.e("Mian Activity", "gallery is oenn");

				} else {

					if (isImgAdded) {
						galleryview.setVisibility(v.INVISIBLE);
						gallery.setVisibility(View.VISIBLE);
						Log.e("Mian Activity::isImgAdded-----", "" + isImgAdded);
						String file_path = captureImageTemp();

						mTv_text.setVisibility(View.VISIBLE);
						mImageViewGalleryImage.setVisibility(View.VISIBLE);
						// alltext.clear();

						openBitmap("file://" + file_path);
						

					} else {
						Log.d("Mian Activity::isImgAdded-----", "" + isImgAdded);
						Toast.makeText(MainActivity.this, "Please select one image...", Toast.LENGTH_SHORT).show();
					}
				}
			}
		});

		surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
		surfaceHolder = surfaceView.getHolder();
		surfaceHolder.addCallback(this);
		surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

		mImageViewCapture.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!isClicked) {
					isClicked = true;

					MainActivity.this.camera.takePicture(null, null, jpegCallback);

				}
			}
		});
		jpegCallback = new PictureCallback() {
			public void onPictureTaken(byte[] data, Camera camera) {

				Log.i("inside jpegcallback", "" + data);

				bitmaptemp = BitmapFactory.decodeByteArray(data, 0, data.length);
				Log.i("bitmap created ", "" + bitmaptemp);

				Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmaptemp, bitmaptemp.getWidth(), bitmaptemp.getHeight(), true);

				/*
				 * Bitmap rotatedBitmap = Bitmap.createBitmap(scaledBitmap, 0,
				 * 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix,
				 * true);
				 */
				mBitmapCamera = scaledBitmap;

				mRelativeLayoutCapture.setVisibility(View.GONE);
				mImageViewGalleryImage.setVisibility(View.VISIBLE);

				Log.i("back width", "" + bitmaptemp.getWidth());
				Log.i("back height", "" + bitmaptemp.getHeight());

				mImageViewGalleryImage.setImageBitmap(mBitmapCamera);

				isClicked = false;
				isImgAdded = true;

			}
		};
	}
//	===============finish on crete=====
	 @Override
	    protected void onRestart() {
	        super.onRestart();
	        Log.i("Main Activity", "On Restart .....");
	    }

	private OnItemClickListener listener = new OnItemClickListener() {

		public void onItemClick(AdapterView<?> parent, View v, int position, long id) {

			runImageProcessor(position);

			Toast.makeText(MainActivity.this, "Processing: " + CommandsPreset.Names.get(position), Toast.LENGTH_SHORT)
					.show();
			//galleryview.setVisibility(View.VISIBLE);
		}
	};

	private void runImageProcessor(int position) {
		ImageProcessingCommand command = getCommand(position);
		ImageProcessor.getInstance().setProcessListener(this);
		ImageProcessor.getInstance().runCommand(command);
	}

	private ImageProcessingCommand getCommand(int position) {
		return CommandsPreset.Preset.get(position);
	}

	@Override
	public void onBackPressed() {
		
		 if (sp1.getString("rate", "").contentEquals("")){
             show_alert("Rate App","Rate this app as 5 stars !!");}
         else
         {   
        	 super.onBackPressed();
		//super.onBackPressed();
		// interstitialAds.show();
         refreshCamera();
         }
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.imageview_camera:
			mLinearLayoutButtons.setVisibility(View.GONE);
			mRelativeLayoutCapture.setVisibility(View.VISIBLE);
			// mImageViewTatoo.setVisibility(View.VISIBLE);
			mImageViewGalleryImage.setVisibility(View.GONE);

			openCamera();
			break;
		case R.id.image_camera:
			galleryview.setVisibility(View.VISIBLE);
			selectText_new();

			break;
		case R.id.imageview_front_camera:
			mLinearLayoutButtons.setVisibility(View.GONE);
			mRelativeLayoutCapture.setVisibility(View.VISIBLE);

			// selectImage_new();
			openFrontFacingCamera();

			refreshCamera();
			isClicked = false;
			break;
		case R.id.imageview_gallery:
			// mImageViewTatoo.setVisibility(View.VISIBLE);
			mLinearLayoutButtons.setVisibility(View.GONE);
			mRelativeLayoutCapture.setVisibility(View.GONE);
			Intent gallerypickerIntent = new Intent(Intent.ACTION_PICK);
			gallerypickerIntent.setType("image/*");
			startActivityForResult(gallerypickerIntent, PICTURE_TAKEN_FROM_GALLERY);
			break;

		case R.id.image_gallery:
			// mImageViewTatoo.setVisibility(View.VISIBLE);
			mLinearLayoutButtons.setVisibility(View.GONE);
			mRelativeLayoutCapture.setVisibility(View.GONE);
			selectImage_new();
			// Intent gallerypickerIntent1 = new Intent(Intent.ACTION_PICK);
			// gallerypickerIntent1.setType("image/*");
			// startActivityForResult(gallerypickerIntent1,
			// PICTURE_TAKEN_FROM_GALLERY);
			break;
		case R.id.imageview_save:
			if (mImageViewGalleryImage.getDrawable() == null) {

				Toast.makeText(this, "please select image first", 0).show();
			} else {
				String filename = captureImage();

				Intent i = new Intent(MainActivity.this, DisplayImage.class);
				i.putExtra("path", "" + filename);
				startActivity(i);
				finish();

			}
			break;
		default:
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Log.i("requestcode", "" + requestCode);
		Log.i("resultcode", "" + resultCode);
		Log.i("data", "" + data);

		switch (requestCode) {

		case PICTURE_TAKEN_FROM_GALLERY:
			if (resultCode == Activity.RESULT_OK) {
				takenPictureData = handleResultFromChooser(data);
				isImgAdded = true;

			}
			break;
		}

		if (takenPictureData != null) {
              
			mImageViewGalleryImage.setVisibility(View.VISIBLE);
			mImageViewGalleryImage.setImageBitmap(takenPictureData);
			isImgAdded = true;

		} else {
			mLinearLayoutButtons.setVisibility(View.VISIBLE);

		}

	}

	private Bitmap handleResultFromChooser(Intent data) {
		Bitmap takenPictureData = null;

		Uri selectedImage = data.getData();
		if (selectedImage != null) {
			try {
				String picturePath = getRealPathFromURI(selectedImage);
				System.out.println("picture path " + picturePath);

				takenPictureData = Media.getBitmap(getContentResolver(), selectedImage);

			} catch (FileNotFoundException e1) {

				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			takenPictureData.compress(Bitmap.CompressFormat.PNG, 100, baos);
		}

		return takenPictureData;
	}

	public String getRealPathFromURI(Uri contentUri) {

		// can post image
		String[] proj = { MediaStore.Images.Media.DATA };
		Cursor cursor = managedQuery(contentUri, proj, null, null, null);
		int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
		cursor.moveToFirst();

		return cursor.getString(column_index);
	}

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		SGD.onTouchEvent(ev);
		return true;
	}

	private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
		@Override
		public boolean onScale(ScaleGestureDetector detector) {
			scale *= detector.getScaleFactor();
			scale = Math.max(0.1f, Math.min(scale, 5.0f));
			matrix.setScale(scale, scale);
			for (i = 0; i < mArrayList.size(); i++) {
				mArrayList.get(i).setImageMatrix(matrix);
			}

			return true;
		}
	}

	public void getList() {
		for (int i = 0; i < frameId.length; i++) {
			Mylist ld = new Mylist();
			ld.setId(((frameId[i])));
			mlist.add(ld);
		}
	}

	@Override
	protected void onResume() {
		camId = Camera.CameraInfo.CAMERA_FACING_BACK;
		refreshCamera();
		isClicked = false;
		super.onResume();
	}

	public void refreshCamera() {
		if (surfaceHolder.getSurface() == null) {
			// preview surface does not exist
			return;
		}

		// stop preview before making changes
		try {
			camera.stopPreview();
		} catch (Exception e) {
			// ignore: tried to stop a non-existent preview
		}

		try {
			camera.setPreviewDisplay(surfaceHolder);
			camera.startPreview();
		} catch (Exception e) {

		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {

		refreshCamera();
	}

	public void openCamera() {
		try {
			// open the camera

			camera = Camera.open();
			camera.setDisplayOrientation(90);
		} catch (RuntimeException e) {
			// check for exceptions
			System.err.println(e);
			return;
		}
		Camera.Parameters param;
		param = camera.getParameters();
		Log.e("camera is open", "");
		// modify parameter
		param.setRotation(90);
		// param.setPreviewSize(352, 288);
		camera.setParameters(param);
		try {
			// The Surface has been created, now tell the camera where to draw
			// the preview.
			camera.setPreviewDisplay(surfaceHolder);
			camera.startPreview();
		} catch (Exception e) {
			// check for exceptions
			System.err.println(e);
			return;
		}
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {

		if (camera != null) {
			camera.stopPreview();
			camera.setPreviewCallback(null);
			camera.release();
			camera = null;
		}
	}

	// ========================

	private String captureImage() {
		// TODO Auto-generated method stub
		OutputStream output;

		Calendar cal = Calendar.getInstance();

		Bitmap bitmap = Bitmap.createBitmap(mRelativeLayoutMain.getWidth(), mRelativeLayoutMain.getHeight(),
				Config.ARGB_8888);
		
//		mBitmapDrawing = ThumbnailUtils.extractThumbnail(mBitmapDrawing,
//				mBitmapDrawing.getWidth(), mBitmapDrawing.getHeight());


		bitmap = ThumbnailUtils.extractThumbnail(bitmap, bitmap.getWidth(), bitmap.getHeight());

		Canvas b = new Canvas(bitmap);
		mRelativeLayoutMain.draw(b);
		
		int x = (mRelativeLayoutMain.getWidth() - mImageViewGalleryImage
				.getWidth()) / 2;
		int y = (mRelativeLayoutMain.getHeight() - mImageViewGalleryImage
				.getHeight()) / 2;
		
		mBitmapMain = Bitmap.createBitmap(bitmap, x, y,
				mImageViewGalleryImage.getWidth(),
				mImageViewGalleryImage.getHeight());



		// Find the SD Card path
		File filepath = Environment.getExternalStorageDirectory();

		// Create a new folder in SD Card
		File dir = new File(filepath.getAbsolutePath() + "/Photo Sticker/");
		dir.mkdirs();

		mImagename = "image" + cal.getTimeInMillis() + ".png";

		// Create a name for the saved image
		file = new File(dir, mImagename);
		MediaScannerConnection.scanFile(this, new String[] { file.getPath() }, null,
				new MediaScannerConnection.OnScanCompletedListener() {
					public void onScanCompleted(String path, Uri uri) {
						// now visible in gallery
					}
				});

		// Show a toast message on successful save
		//Toast.makeText(MainActivity.this, "Image Saved to SD Card", Toast.LENGTH_SHORT).show();

		try {

			output = new FileOutputStream(file);
			// Compress into png format image from 0% - 100%
			mBitmapMain.compress(Bitmap.CompressFormat.PNG, 100, output);
			output.flush();
			output.close();
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return file.getPath();

	}

	// =====================

	public void openFrontFacingCamera() {
		int numberOfCamera = Camera.getNumberOfCameras();

		if (numberOfCamera > 0) {
			if (camId == Camera.CameraInfo.CAMERA_FACING_BACK) {
				camId = Camera.CameraInfo.CAMERA_FACING_FRONT;
				Toast.makeText(getApplicationContext(), "BACK TO FRONT", 1000).show();
				try {
					camera.release();
					camera = Camera.open(camId);
					camera.setPreviewDisplay(surfaceHolder);
					//camera.setDisplayOrientation(90);
					camera.startPreview();
				} catch (RuntimeException e) {

				} catch (IOException e) {
				}
			} else if (camId == Camera.CameraInfo.CAMERA_FACING_FRONT) {
				camId = Camera.CameraInfo.CAMERA_FACING_BACK;
				Toast.makeText(getApplicationContext(), "FRONT TO BACK",

				1000).show();
				try {
					camera.release();
					camera = Camera.open(camId);
					camera.setDisplayOrientation(90);
					camera.setPreviewDisplay(surfaceHolder);
					camera.startPreview();
				} catch (RuntimeException e) {
				} catch (IOException e) {
				}
			}
		}
	}

	public void addView(myView myView_) {

		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
		imageViewArray.add(myView_);
		mRelativeLayoutMain.addView(myView_, params);

	}

	public void addOnclick() {
		for (myView view : imageViewArray) {

			view.setOnTouchListener(null);

			view.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					v.setVisibility(View.GONE);
				}
			});

		}
	}

	public void addmultitouch() {

		for (myView view : imageViewArray) {

			view.setOnTouchListener(new MultiTouchListener());

		}

	}

	public void ckhDelete() {

		if (isDelete) {
			addOnclick();
			delete_btn.setBackgroundColor(Color.RED);

		} else {
			addmultitouch();
			delete_btn.setBackgroundColor(Color.TRANSPARENT);
		}

	}

	private void setCamFocusMode() {

		if (null == camera) {
			return;
		}

		/* Set Auto focus */
		Parameters parameters = camera.getParameters();
		List<String> focusModes = parameters.getSupportedFocusModes();
		if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
			parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
		} else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
			parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
		}

		camera.setParameters(parameters);
	}

	public void selectImage_new() {

		// ===============
		// galleryview.setVisibility(View.INVISIBLE);
		final Dialog dialog = new Dialog(MainActivity.this);
		// Include dialog.xml file

		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		dialog.setContentView(R.layout.selectdialog);
		dialog.setCancelable(false);
		// Set dialog title

		dialog.show();

		dialog.findViewById(R.id.gallary).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				interstitial = new InterstitialAd(getApplicationContext());
				// Insert the Ad Unit ID
				interstitial.setAdUnitId("ca-app-pub-2691806550199991/7689983468");
				AdView adView = (AdView) findViewById(R.id.adView);
				
				// Request for Ads
				AdRequest adRequest;
				adRequest = new AdRequest.Builder()
				// Add a test device to show Test Ads
						.addTestDevice(AdRequest.DEVICE_ID_EMULATOR).addTestDevice("CC5F2C72DF2B356BBF0DA198").build();
				// Load ads into Banner Ads
				interstitial.loadAd(adRequest);

				// Prepare an Interstitial Ad Listener
				interstitial.setAdListener(new AdListener() {
					public void onAdLoaded() {
						// Call displayInterstitial() function
						displayInterstitial();
					}

				});
				Intent gallerypickerIntent1 = new Intent(Intent.ACTION_PICK);
				gallerypickerIntent1.setType("image/*");
				startActivityForResult(gallerypickerIntent1, PICTURE_TAKEN_FROM_GALLERY);

				dialog.dismiss();
			}
		});
		

		dialog.findViewById(R.id.camera).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				mImageViewGalleryImage.setVisibility(View.GONE);
				// mImageViewTatoo.setVisibility(View.VISIBLE);
				mLinearLayoutButtons.setVisibility(View.GONE);
				mRelativeLayoutCapture.setVisibility(View.VISIBLE);
				openCamera();
				refreshCamera();
				isClicked = false;

				dialog.dismiss();
			}
		});

		dialog.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				dialog.dismiss();
				mLinearLayoutButtons.setVisibility(v.VISIBLE);
			}
		});

	}

	public void displayInterstitial() {
		// If Ads are loaded, show Interstitial else show nothing.
		if (interstitial.isLoaded()) {
			interstitial.show();
		}
	}
	private String captureImageTemp() {
		// TODO Auto-generated method stub
		OutputStream output;

		Calendar cal = Calendar.getInstance();

		Bitmap bitmap = Bitmap.createBitmap(mImageViewGalleryImage.getWidth(), mImageViewGalleryImage.getHeight(),
				Config.ARGB_8888);

		bitmap = ThumbnailUtils.extractThumbnail(bitmap, mImageViewGalleryImage.getWidth(),
				mImageViewGalleryImage.getHeight());

		Canvas b = new Canvas(bitmap);
		mImageViewGalleryImage.draw(b);

		// Find the SD Card path
		File filepath = Environment.getExternalStorageDirectory();

		// Create a new folder in SD Card
		File dir = new File(filepath.getAbsolutePath() + "/PicMaker/");
		dir.mkdirs();

		mImagename = "image.png";
		ImageProcessor.getInstance().setBitmap(bitmap);
		// Create a name for the saved image
		file = new File(dir, mImagename);

		// Show a toast message on successful save
	//	Toast.makeText(MainActivity.this, "Image Saved to SD Card", Toast.LENGTH_SHORT).show();

		try {

			output = new FileOutputStream(file);
			// Compress into png format image from 0% - 100%
			bitmap.compress(Bitmap.CompressFormat.PNG, 100, output);
			output.flush();
			output.close();
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.i("path", file.getPath());
		return file.getPath();
	}

	// open bitmap mathod
	private void openBitmap(String imageUri) {
		Log.i("Photo Editor", "Open Bitmap");
		Bitmap b;
		try {
			b = BitmapScalingUtil.bitmapFromUri(this, Uri.parse(imageUri));
			if (b != null) {
				Log.i("Photo Editor", "Opened Bitmap Size: " + b.getWidth() + " " + b.getHeight());
			}
			ImageProcessor.getInstance().setBitmap(b);
			imageProcessor = ImageProcessor.getInstance();
			// progressBar = (ProgressBar) findViewById(R.id.progressBar);
			gallery.setVisibility(View.VISIBLE);
			initializeValues();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void initializeValues() {
		final Object data = getLastNonConfigurationInstance();
		if (data == null) {
			mImageViewGalleryImage.setImageBitmap(imageProcessor.getBitmap());
		} else {
			restoreSavedValues(data);
		}

	}

	private void restoreSavedValues(Object data) {
		Bundle savedValues = (Bundle) data;

		int bitmapToRead = savedValues.getInt("BITMAP");
		boolean isRunning = savedValues.getBoolean("IS_RUNNING");
		int selectedFilterIdx = savedValues.getInt("SELECTED_FILTER_POSITION");

		if (bitmapToRead == RESTORE_PREVIEW_BITMAP) {
			mImageViewGalleryImage.setImageBitmap(imageProcessor.getLastResultBitmap());
		} else {
			mImageViewGalleryImage.setImageBitmap(imageProcessor.getBitmap());
		}

		gallery.setSelection(selectedFilterIdx);

		if (isRunning) {
			onProcessStart();
			imageProcessor.setProcessListener(this);
		}
	}

	public class MyAdapter extends ArrayAdapter<String> {

		public MyAdapter(Context context, int textViewResourceId, String[] objects) {
			super(context, textViewResourceId, objects);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getCustomView(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getCustomView(position, convertView, parent);
		}

		public View getCustomView(int position, View convertView, ViewGroup parent) {

			LayoutInflater inflater = getLayoutInflater();
			View row = inflater.inflate(R.layout.spinner_row, parent, false);

			TextView label = (TextView) row.findViewById(R.id.textView1);
			label.setText("FONT");

			Typeface face = Typeface.createFromAsset(getAssets(), style[position]);

			label.setTypeface(face);

			return row;
		}

	}

	private void showColorPickerDialogDemo() {

		int initialColor = global.getColor();

		ColorPickerDialog colorPickerDialog = new ColorPickerDialog(this, initialColor, new OnColorSelectedListener() {

			@Override
			public void onColorSelected(int color) {
				mIbtn_color_text.setBackgroundColor(color);
				global.setColor(color);

			}

		});
		colorPickerDialog.show();

	}

	public void selectText_new() {

		if (mTv_text.getVisibility() == View.INVISIBLE) {
			return;
		}

		if (isImgAdded) {
			Log.e("value is------------>", "" + isImgAdded);

		} else {
			Toast.makeText(MainActivity.this, "Please select Image first...", Toast.LENGTH_SHORT).show();
			return;
		}

		LayoutParams mParams1;

		gallery.setVisibility(View.INVISIBLE);

		final Dialog dialog = new Dialog(MainActivity.this);
		// Include dialog.xml file

		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		dialog.setContentView(R.layout.text_custom_dialog);
		dialog.setCancelable(false);
		// Set dialog title

		edText = (EditText) dialog.findViewById(R.id.et_view);

		edText.setText("" + mTv_text.getText().toString().trim());
		dialog.setTitle("Text Appearance");
		dialog.show();
		mSpinner_text_style = (Spinner) dialog.findViewById(R.id.spinner_text_style);
		mIbtn_color_text = (ImageButton) dialog.findViewById(R.id.ibtn_color_text);

		MyAdapter adapter = new MyAdapter(MainActivity.this, R.layout.spinner_row, style);
		mSpinner_text_style.setAdapter(adapter);

		mSpinner_text_style.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// TODO Auto-generated method stub
				global.setPosition(arg2);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});

		mIbtn_color_text.setBackgroundColor(global.getColor());

		mIbtn_color_text.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showColorPickerDialogDemo();

			}
		});

		Button declineButton = (Button) dialog.findViewById(R.id.btn_cancel);
		// if decline button is clicked, close the custom dialog
		declineButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Close dialog
				dialog.dismiss();
			}
		});

		Button Ok = (Button) dialog.findViewById(R.id.btn_ok);
		// if decline button is clicked, close the custom dialog
		Ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Close dialog

				mTv_text.setTextColor(global.getColor());
				Typeface face = Typeface.createFromAsset(getAssets(), style[global.getPosition()]);

				mTv_text.setTypeface(face);

				String s = edText.getText().toString().trim();
				if (s.length() > 0) {
					mTv_text.setText(s);
					dialog.dismiss();

				} else {
					Toast.makeText(MainActivity.this, "Add Some Text...", Toast.LENGTH_SHORT).show();
				}
				galleryview.setVisibility(View.VISIBLE);
			}
		});

		// ===========================================

		mTv_text.setTextSize(58);
		mTv_text.setOnTouchListener(new MultiTouchListener());

		// alltext.add(mTv_text);

	}

	public class ImageAdapter extends BaseAdapter {
		int galleryItemBackground;
		private Context context;
		private Integer[] mImageIds = CommandsPreset.ImageIds;

		public ImageAdapter(Context c) {
			context = c;
			TypedArray attr = context.obtainStyledAttributes(R.styleable.FiltersGallery);
			galleryItemBackground = attr.getResourceId(R.styleable.FiltersGallery_android_galleryItemBackground, 0);
			attr.recycle();
		}

		public int getCount() {
			return mImageIds.length;
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView imageView = new ImageView(context);

			imageView.setImageResource(mImageIds[position]);
			imageView.setLayoutParams(new Gallery.LayoutParams(150, 150));
			imageView.setScaleType(ImageView.ScaleType.FIT_XY);
			imageView.setBackgroundResource(galleryItemBackground);

			return imageView;
		}
	}

	@Override
	public void onProcessStart() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProcessEnd(Bitmap result) {
		// TODO Auto-generated method stub
		mImageViewGalleryImage.setImageBitmap(result);
		mImageViewGalleryImage.invalidate();
	}
	
	
		 
		 public void show_alert(String title,String msg) {

		        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
		                MainActivity.this);

		        // set title
		        alertDialogBuilder.setTitle(title);

		        // set dialog message
		        alertDialogBuilder
		                .setMessage(msg)
		                .setCancelable(true)
		                .setIcon(R.drawable.icon_cancel).setNegativeButton("Later", new DialogInterface.OnClickListener() {

		            @Override
		            public void onClick(DialogInterface dialog, int which) {
		                // TODO Auto-generated method stub
		                rate1.dismiss();
		               // super.onBackPressed();
		        	    finish();

		            }
		        })
		                .setPositiveButton("Now",new DialogInterface.OnClickListener() {
		                    public void onClick(DialogInterface dialog,int id) {
		                        // if this button is clicked, close
		                        // current activity
		                        SharedPreferences.Editor editor=sp1.edit();
		                        editor.putString("rate", "true");
		                        editor.commit();
//			  					Intent web=new Intent(MainActivity.this,webview.class);
//			  					startActivity(web);

		                        final String appName = getPackageName();
		                        try {
		                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id="+appName)));
		                        } catch (android.content.ActivityNotFoundException anfe) {
		                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id="+appName)));

		                        }
		                    }
		                });



		        // create alert dialog
		        AlertDialog alertDialog = alertDialogBuilder.create();
		        // show it
		        alertDialog.show();

		        Button b = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
		        Button b1 = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
		        if(b != null)
		            b.setTextColor(Color.RED);
		        if(b1 != null)
		            b1.setTextColor(Color.RED);
		    }
	

}
