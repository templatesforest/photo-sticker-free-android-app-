package com.passiontocode.editoractivity;

public class EditorSaveConstants {
	public static final int RESTORE_SAVED_BITMAP = 0;
	public static final int RESTORE_PREVIEW_BITMAP = 1;
}
